Name : Custom Static Page
Description : Allows users to put any PHP/HTML/Text in to their own page with its own menu link and sidebar
Authors : Alex Falk [http://weborganizm.org/creator/alexfalk] RiverVanRain [http://weborganizm.org/creator/rivervanrain]
Web : http://weborganizm.org/crewz/p/1983/personal-net
License : GNU General Public License version 2
Copyright : weborganiZm 2k13