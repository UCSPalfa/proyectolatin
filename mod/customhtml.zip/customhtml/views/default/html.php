<center>
<strong>Open the file:</strong><br>
<code>elgg/mod/customhtml/views/default/html.php</code>
<br><br>
<strong>And edit all in there</strong><br>
</center>